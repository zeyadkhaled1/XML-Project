#ifndef BIT_H
#define BIT_H
#include <cassert>
#include <string>
#include <stdexcept>
#include <vector>
auto to_bit_stream(const std::string& bytes);
#endif // BIT_H
