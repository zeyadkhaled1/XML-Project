#ifndef MINIFY_H
#define MINIFY_H
#include<iostream>
#include<string>

using namespace std;

string minify_XML(string xml_file);
string remove_spaces(const string& s);
#endif // MINIFY_H
