#ifndef CONSISTENCY_H
#define CONSISTENCY_H
#include<string>
using namespace std;
string Check_XML_Consistency(string xml_file);

#endif // CONSISTENCY_H
