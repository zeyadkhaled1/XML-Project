#ifndef CONSISTENCY_H
#define CONSISTENCY_H
#include<iostream>
#include<string>
#include<stack>
using namespace std;
string Check_XML_Consistency(string xml_file);

#endif // CONSISTENCY_H
