#pragma once

#include<iostream>
#include<string>
#include<stack>

using namespace std;

string Get_user_id_name(string input, int found_id);
string Graph_present(string xml_file);
