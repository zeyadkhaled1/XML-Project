#ifndef CHECK_ERRORS_H
#define CHECK_ERRORS_H
#include<iostream>
#include<string>
#include<stack>
#include<vector>

using namespace std;

string Check_XML_Errors(string xml_file);
#endif // CHECK_ERRORS_H
