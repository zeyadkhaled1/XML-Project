#ifndef PRETTIFY_H
#define PRETTIFY_H
#include<iostream>
#include<string>
#include<stack>
using namespace std;
string format_XML(string xml_file);
#endif // PRETTIFY_H
